function loadList() {
  const xmlhttp = new XMLHttpRequest();
  xmlhttp.onload = function() {
      const myObj = JSON.parse(this.responseText);
      let text = "<table border='1'>"
      for (let x in myObj) {
        text += "<tr><td><img height=\"40\" width=\"37\" src=\"" + myObj[x].image + "\"/></td></tr>";
        text += "<tr><td>" + myObj[x].name + "</td></tr>";
        text += "<tr><td><button onclick=\"deleteButtonClicked("+ myObj[x].id + ")\">Delete</button></td></tr>";
      }
      text += "</table>"
      document.getElementById("list").innerHTML = text;
  }
  // адрес, куда мы отправим нашу JSON-строку
  let url = "http://localhost:3000/posts";
  xmlhttp.open("GET", url);
  xmlhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
  xmlhttp.send();

  console.log("GET: http://localhost:3000/posts");  
}